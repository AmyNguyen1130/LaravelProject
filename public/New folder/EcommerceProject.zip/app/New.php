<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class New extends Model
{
    protected $table = 'news'; // Tên của bảng trong database
    protected $guarded = ['title','content','image']; // Lấy hết các trường trong bảng đó

    public $timestamps = true;
}
