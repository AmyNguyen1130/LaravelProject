@extends("admin.layouts.master")

@section("admin.admin-content")

Table here

@endsection