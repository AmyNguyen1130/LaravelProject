@extends("layouts/master")

@section("content")
	
<div class="container">
    <div id="content">
        <p>Neque porro quisquam est, qui dolom ipsum quia dolor sit amet. Consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad mieniam, quis nostxerationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
        <div class="space25">&nbsp;</div>
        
        <!--price table-->
        <div class="col-sm-3">
        <div class="beta-pricing">
            <div class="pri-title"><h4>Standard</h4></div>
            <div class="clear"></div>
            <span class="pri-amo">
            <span class="price-currency">$</span>
                <span class="price-amount">5</span>
                <sup>99</sup>
                <sub>mountly</sub>
            </span>
            <div class="clear"></div>
            <span class="beta-price-list">5 Projects</span>
            <span class="beta-price-list">5 GB Storage</span>
            <span class="beta-price-list">Unlimited Users</span>
            <span class="beta-price-list">10 GB Bandwith</span>
            <span class="beta-price-list">Enhanced Security</span>
            <span class="beta-price-button"><a href="#" class="beta-btn beta-btn-2d">Sign up Now <i class="fa fa-chevron-right"></i></a></span>
        </div>
        </div>
        <!--price table-->
        <!--price table-->
        <div class="col-sm-3">
        <div class="beta-pricing">
            <div class="pri-title"><h4>Standard</h4></div>
            <div class="clear"></div>
            <span class="pri-amo">
            <span class="price-currency">$</span>
                <span class="price-amount">5</span>
                <sup>99</sup>
                <sub>mountly</sub>
            </span>
            <div class="clear"></div>
            <span class="beta-price-list">5 Projects</span>
            <span class="beta-price-list">5 GB Storage</span>
            <span class="beta-price-list">Unlimited Users</span>
            <span class="beta-price-list">10 GB Bandwith</span>
            <span class="beta-price-list">Enhanced Security</span>
            <span class="beta-price-button"><a href="#" class="beta-btn beta-btn-2d">Sign up Now <i class="fa fa-chevron-right"></i></a></span>
        </div>
        </div>
        <!--price table-->
        <!--price table-->
        <div class="col-sm-3">
        <div class="beta-pricing">
            <div class="pri-title"><h4>Standard</h4></div>
            <div class="clear"></div>
            <span class="pri-amo">
            <span class="price-currency">$</span>
                <span class="price-amount">5</span>
                <sup>99</sup>
                <sub>mountly</sub>
            </span>
            <div class="clear"></div>
            <span class="beta-price-list">5 Projects</span>
            <span class="beta-price-list">5 GB Storage</span>
            <span class="beta-price-list">Unlimited Users</span>
            <span class="beta-price-list">10 GB Bandwith</span>
            <span class="beta-price-list">Enhanced Security</span>
            <span class="beta-price-button"><a href="#" class="beta-btn beta-btn-2d">Sign up Now <i class="fa fa-chevron-right"></i></a></span>
        </div>
        </div>
        <!--price table-->
        <!--price table-->
        <div class="col-sm-3">
        <div class="beta-pricing">
            <div class="pri-title"><h4>Standard</h4></div>
            <div class="clear"></div>
            <span class="pri-amo">
            <span class="price-currency">$</span>
                <span class="price-amount">5</span>
                <sup>99</sup>
                <sub>mountly</sub>
            </span>
            <div class="clear"></div>
            <span class="beta-price-list">5 Projects</span>
            <span class="beta-price-list">5 GB Storage</span>
            <span class="beta-price-list">Unlimited Users</span>
            <span class="beta-price-list">10 GB Bandwith</span>
            <span class="beta-price-list">Enhanced Security</span>
            <span class="beta-price-button"><a href="#" class="beta-btn beta-btn-2d">Sign up Now <i class="fa fa-chevron-right"></i></a></span>
        </div>
        </div>
        <!--price table-->
        
        
        <div class="clear"></div>
        <div class="space20">&nbsp;</div>
        <p>Neque porro quisquam est, qui dolom ipsum quia dolor sit amet. Consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad mieniam, quis nostxerationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
    </div> <!-- #content -->
</div> <!-- .container -->


@endsection